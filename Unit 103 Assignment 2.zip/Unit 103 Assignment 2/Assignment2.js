let productName;
let productQuantity;
let productPrice;

productName = prompt("What is the products name: ");
productQuantity = prompt("What is the products name: ");
productPrice = prompt("What is the products price: ");

function CalculateTotalPrice(a){
    a += .7;
    console.log("The total price of the item is: "+ a);
}

CalculateTotalPrice(productPrice);
